package interfaces;

public interface Observer {
    void update();
}
